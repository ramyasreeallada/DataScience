var config = {
	database: {
		host:	  '82.196.6.85', 	// database host
		user: 	  'root', 		// your database username
		password: 'root@#123', 		// your database password
		port: 	  3306, 		// default MySQL port
		db: 	  'my_db' 		// your database name
	},
	server: {
		host: 'localhost',
		port: '3030'
	}
}

module.exports = config
