var express = require('express')
var app = express()

// SHOW LIST OF USERS
app.get('/', function (req, res, next) {
    req.getConnection(function (error, conn) {
        conn.query('SELECT * FROM users ORDER BY id DESC', function (err, rows, fields) {
            //if(err) throw err
            if (err) {
                req.flash('error', err)
                res.render('user/list', {
                    title: 'User List',
                    data: ''
                })
            } else {
                // render to views/user/list.ejs template file
                res.render('user/list', {
                    title: 'User List',
                    data: rows
                })
            }
        })
    })
})

// SHOW ADD USER FORM
app.get('/add', function (req, res, next) {
    // render to views/user/add.ejs
    res.render('user/add', {
        title: 'Add New User',
        name: '',
        age: '',
        email: ''
    })
})



// ADD NEW USER POST ACTION
app.post('/add', function (req, res, next) {
    req.assert('name', 'Name is required').notEmpty()           //Validate name
    req.assert('age', 'Age is required').notEmpty()             //Validate age
    req.assert('email', 'A valid email is required').isEmail()  //Validate email

    var errors = req.validationErrors()

    if (!errors) {   //No errors were found.  Passed Validation!

        /********************************************
         * Express-validator module

         req.body.comment = 'a <span>comment</span>';
         req.body.username = '   a user    ';

         req.sanitize('comment').escape(); // returns 'a &lt;span&gt;comment&lt;/span&gt;'
         req.sanitize('username').trim(); // returns 'a user'
         ********************************************/
        var user = {
            name: req.sanitize('name').escape().trim(),
            age: req.sanitize('age').escape().trim(),
            email: req.sanitize('email').escape().trim()
        }

        req.getConnection(function (error, conn) {
            conn.query('INSERT INTO users SET ?', user, function (err, result) {
                //if(err) throw err
                if (err) {
                    req.flash('error', err)

                    // render to views/user/add.ejs
                    res.render('user/add', {
                        title: 'Add New User',
                        name: user.name,
                        age: user.age,
                        email: user.email
                    })
                } else {
                    req.flash('success', 'Data added successfully!')

                    // render to views/user/add.ejs
                    res.render('user/add', {
                        title: 'Add New User',
                        name: '',
                        age: '',
                        email: ''
                    })
                }
            })
        })
    } else {   //Display errors to user
        var error_msg = ''
        errors.forEach(function (error) {
            error_msg += error.msg + '<br>'
        })
        req.flash('error', error_msg)

        /**
         * Using req.body.name
         * because req.param('name') is deprecated
         */
        res.render('user/add', {
            title: 'Add New User',
            name: req.body.name,
            age: req.body.age,
            email: req.body.email
        })
    }
})

// SHOW EDIT USER FORM
app.get('/edit/(:id)', function (req, res, next) {
    req.getConnection(function (error, conn) {
        conn.query('SELECT * FROM users WHERE id = ' + req.params.id, function (err, rows, fields) {
            if (err)
                throw err

            // if user not found
            if (rows.length <= 0) {
                req.flash('error', 'User not found with id = ' + req.params.id)
                res.redirect('/users')
            } else { // if user found
                // render to views/user/edit.ejs template file
                res.render('user/edit', {
                    title: 'Edit User',
                    //data: rows[0],
                    id: rows[0].id,
                    name: rows[0].name,
                    age: rows[0].age,
                    email: rows[0].email
                })
            }
        })
    })
})

// EDIT USER POST ACTION
app.put('/edit/(:id)', function (req, res, next) {
    req.assert('name', 'Name is required').notEmpty()           //Validate name
    req.assert('age', 'Age is required').notEmpty()             //Validate age
    req.assert('email', 'A valid email is required').isEmail()  //Validate email

    var errors = req.validationErrors()

    if (!errors) {   //No errors were found.  Passed Validation!

        /********************************************
         * Express-validator module

         req.body.comment = 'a <span>comment</span>';
         req.body.username = '   a user    ';

         req.sanitize('comment').escape(); // returns 'a &lt;span&gt;comment&lt;/span&gt;'
         req.sanitize('username').trim(); // returns 'a user'
         ********************************************/
        var user = {
            name: req.sanitize('name').escape().trim(),
            age: req.sanitize('age').escape().trim(),
            email: req.sanitize('email').escape().trim()
        }

        req.getConnection(function (error, conn) {
            conn.query('UPDATE users SET ? WHERE id = ' + req.params.id, user, function (err, result) {
                //if(err) throw err
                if (err) {
                    req.flash('error', err)

                    // render to views/user/add.ejs
                    res.render('user/edit', {
                        title: 'Edit User',
                        id: req.params.id,
                        name: req.body.name,
                        age: req.body.age,
                        email: req.body.email
                    })
                } else {
                    req.flash('success', 'Data updated successfully!')

                    // render to views/user/add.ejs
                    res.render('user/edit', {
                        title: 'Edit User',
                        id: req.params.id,
                        name: req.body.name,
                        age: req.body.age,
                        email: req.body.email
                    })
                }
            })
        })
    } else {   //Display errors to user
        var error_msg = ''
        errors.forEach(function (error) {
            error_msg += error.msg + '<br>'
        })
        req.flash('error', error_msg)

        /**
         * Using req.body.name
         * because req.param('name') is deprecated
         */
        res.render('user/edit', {
            title: 'Edit User',
            id: req.params.id,
            name: req.body.name,
            age: req.body.age,
            email: req.body.email
        })
    }
})

// DELETE USER
app.delete('/delete/(:id)', function (req, res, next) {
    var user = {id: req.params.id}

    req.getConnection(function (error, conn) {
        conn.query('DELETE FROM users WHERE id = ' + req.params.id, user, function (err, result) {
            //if(err) throw err
            if (err) {
                req.flash('error', err)
                // redirect to users list page
                res.redirect('/users')
            } else {
                req.flash('success', 'User deleted successfully! id = ' + req.params.id)
                // redirect to users list page
                res.redirect('/users')
            }
        })
    })
})

app.get('/export', function (req, res, next) {

    var test = 'test'
    var data = [
        {
            name: 'Salmons Creek',
            image: 'https://farm6.staticflickr.com/5479/11694969344_42dff96680.jpg',
            description: "Great place to go fishin' Bacon ipsum dolor amet kielbasa cow"
        },
        {
            name: 'Granite Hills',
            image: 'https://farm5.staticflickr.com/4103/5088123249_5f24c3202c.jpg',
            description: "It's just a hill.  Made of granite.  Nothing more! Cow doner."
        },
        {
            name: 'Wildwood Miew',
            image: 'https://farm5.staticflickr.com/4016/4369518024_0f64300987.jpg',
            description: 'All campsites.  All the time.Short ribs pastrami drumstick.'
        },
        {
            name: 'Lake Fooey',
            image: 'https://farm7.staticflickr.com/6138/6042439726_9efecf8348.jpg',
            description: 'Hills and lakes and lakes and hills.  Pork ribeye pork chop.'
        },
        {
            name: 'Lake Fooey Duplicate',
            image: 'https://farm7.staticflickr.com/6138/6042439726_9efecf8348.jpg',
            description: 'Hills and lakes and lakes and hills.  Pork ribeye pork chop.'
        },
        {
            name: 'Duplicate Test',
            image: 'https://farm7.staticflickr.com/6138/6042439726_9efecf8348.jpg',
            description: 'Hills and lakes and lakes and hills.  Pork ribeye pork chop.'
        }
    ];
    res.render('user/export', {
        title: 'Export Users',
        data: data,
    })

})

app.get('/ajax', function (req, res, next) {


    var data = [
        {
            id: '1',
            name: "Name-1"
        },
        {
            id: '2',
            name: "Name-2"
        },
        {
            id: '3',
            name: "Name-3"
        },
        {
            id: '4',
            name: "Name-4"
        },
        {
            id: '5',
            name: "Name-5"
        }
    ];
    res.render('user/ajax', {
        title: 'Ajax Call Example',
        data: data,
    })

})


app.post('/endpoint', function (req, res) {
    var obj = {};
    console.log('body: ' + JSON.stringify(req.body));
    res.send(req.body);
});


module.exports = app
